package com.example.a3d3project2;

public class MyClass {

    public String placeholder(){
        return "";
    }
}